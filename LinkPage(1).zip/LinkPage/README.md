# LinkPage

A lightweight link-in-bio SaaS built with Next.js, Tailwind CSS and Supabase.

## Local setup

1. Install Node 22+.
2. `npm install`
3. Create a Supabase project.
4. Run `supabase/schema.sql` in the Supabase SQL editor.
5. Copy `.env.example` to `.env.local` and add the Supabase URL + anon key.
6. `npm run dev`

## Deploy

The app is designed for Antideploy. It detects Next.js from `package.json` and can build/run with `next build` / `next start`. No Dockerfile is required.

Required environment variables:
- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`
