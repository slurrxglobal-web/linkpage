create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null unique references auth.users(id) on delete cascade,
  username text not null unique check (username ~ '^[a-z0-9_]{3,30}$'),
  name text not null default 'Your Name',
  bio text not null default '',
  avatar_url text,
  theme text not null default 'minimal',
  background text not null default 'midnight',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table if not exists public.links (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid not null references public.profiles(id) on delete cascade,
  title text not null,
  url text not null,
  type text not null default 'link',
  position int not null default 0,
  enabled boolean not null default true,
  created_at timestamptz not null default now()
);
create table if not exists public.page_views (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now()
);
create table if not exists public.link_clicks (
  id uuid primary key default gen_random_uuid(),
  link_id uuid not null references public.links(id) on delete cascade,
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.links enable row level security;
alter table public.page_views enable row level security;
alter table public.link_clicks enable row level security;

drop policy if exists "Public profiles are viewable" on public.profiles;
create policy "Public profiles are viewable" on public.profiles for select using (true);
drop policy if exists "Users manage own profile" on public.profiles;
create policy "Users manage own profile" on public.profiles for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

drop policy if exists "Public links are viewable" on public.links;
create policy "Public links are viewable" on public.links for select using (enabled = true or exists(select 1 from public.profiles p where p.id=profile_id and p.user_id=auth.uid()));
drop policy if exists "Users manage own links" on public.links;
create policy "Users manage own links" on public.links for all using (exists(select 1 from public.profiles p where p.id=profile_id and p.user_id=auth.uid())) with check (exists(select 1 from public.profiles p where p.id=profile_id and p.user_id=auth.uid()));

create index if not exists profiles_username_idx on public.profiles(username);
create index if not exists links_profile_idx on public.links(profile_id,position);


create or replace function public.track_page_view(p_profile_id uuid)
returns void language plpgsql security definer set search_path=public as $$
begin insert into public.page_views(profile_id) values (p_profile_id); end; $$;
create or replace function public.track_link_click(p_link_id uuid)
returns void language plpgsql security definer set search_path=public as $$
begin insert into public.link_clicks(link_id) values (p_link_id); end; $$;
grant execute on function public.track_page_view(uuid) to anon, authenticated;
grant execute on function public.track_link_click(uuid) to anon, authenticated;

drop policy if exists "Users view own page analytics" on public.page_views;
create policy "Users view own page analytics" on public.page_views for select using (exists(select 1 from public.profiles p where p.id=profile_id and p.user_id=auth.uid()));
drop policy if exists "Users view own click analytics" on public.link_clicks;
create policy "Users view own click analytics" on public.link_clicks for select using (exists(select 1 from public.links l join public.profiles p on p.id=l.profile_id where l.id=link_id and p.user_id=auth.uid()));
