import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase-server";

export async function GET(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const supabase = await createClient();
  const { data: link } = await supabase.from("links").select("id,url").eq("id", id).maybeSingle();
  if (!link) return new NextResponse("Not found", { status: 404 });
  await supabase.rpc("track_link_click", { p_link_id: link.id });
  return NextResponse.redirect(new URL(link.url));
}
