import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'LinkPage — One link. Everything you share.',
  description: 'Create a clean, beautiful link-in-bio page in minutes.',
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
