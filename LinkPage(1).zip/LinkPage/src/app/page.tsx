import Link from 'next/link';

const features = [
  ['01','Your page','One clean URL for everything you want people to find.'],
  ['02','Your style','Photo, bio, background and buttons that feel like you.'],
  ['03','Your audience','Simple click and view analytics without the clutter.'],
];

export default function Home() {
  return <main className="min-h-screen overflow-hidden grid-bg">
    <nav className="mx-auto flex max-w-6xl items-center justify-between px-5 py-6">
      <Link href="/" className="text-lg font-black tracking-tight">LINK<span className="text-white/45">PAGE</span></Link>
      <Link href="/auth" className="rounded-full border border-white/15 px-4 py-2 text-sm font-semibold transition hover:bg-white hover:text-black">Sign in</Link>
    </nav>
    <section className="mx-auto max-w-6xl px-5 pb-20 pt-16 text-center sm:pt-28">
      <div className="fade-up mx-auto mb-6 inline-flex rounded-full border border-white/10 bg-white/5 px-4 py-2 text-xs text-white/60">Your little corner of the internet.</div>
      <h1 className="fade-up mx-auto max-w-4xl text-5xl font-black tracking-[-.05em] sm:text-7xl lg:text-8xl">One link.<br/><span className="text-white/35">Everything you share.</span></h1>
      <p className="fade-up mx-auto mt-7 max-w-xl text-base leading-7 text-white/55 sm:text-lg">Create a beautiful, fast mini-page for your links, socials and contacts. Share one URL everywhere.</p>
      <div className="fade-up mt-9 flex flex-col justify-center gap-3 sm:flex-row">
        <Link href="/auth?mode=signup" className="rounded-full bg-white px-7 py-3.5 font-bold text-black transition hover:scale-[1.02]">Create my page →</Link>
        <a href="#features" className="rounded-full border border-white/12 px-7 py-3.5 font-semibold text-white/75 hover:bg-white/5">See how it works</a>
      </div>
      <div className="mx-auto mt-16 max-w-3xl rounded-[2rem] border border-white/10 bg-[#0b0b0d]/90 p-3 text-left shadow-2xl glow sm:mt-24">
        <div className="rounded-[1.5rem] border border-white/8 bg-[#111114] p-6 sm:p-10">
          <div className="mx-auto max-w-md text-center">
            <div className="mx-auto mb-4 grid h-20 w-20 place-items-center rounded-full bg-gradient-to-br from-white to-white/25 text-2xl font-black text-black">R</div>
            <h2 className="text-2xl font-bold">Rajput Ads</h2><p className="mt-1 text-sm text-white/45">Meta & Google Ads 🚀</p>
            <div className="mt-7 space-y-3">
              {['🟢  WhatsApp Me','🔵  Join Telegram','📸  Instagram','▶️  YouTube','🌐  Visit Website'].map(x=><div key={x} className="rounded-2xl border border-white/8 bg-white/[.045] px-5 py-4 text-sm font-semibold transition hover:bg-white/10">{x}</div>)}
            </div><p className="mt-7 text-[11px] text-white/25">Powered by LinkPage</p>
          </div>
        </div>
      </div>
    </section>
    <section id="features" className="mx-auto grid max-w-6xl gap-4 px-5 pb-24 md:grid-cols-3">
      {features.map(([n,t,d])=><div key={n} className="glass rounded-3xl p-6"><span className="text-xs text-white/30">{n}</span><h3 className="mt-8 text-xl font-bold">{t}</h3><p className="mt-2 text-sm leading-6 text-white/45">{d}</p></div>)}
    </section>
    <footer className="border-t border-white/8 px-5 py-8 text-center text-xs text-white/25">© {new Date().getFullYear()} LinkPage</footer>
  </main>;
}
