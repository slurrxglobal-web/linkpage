'use client';
import { Suspense, useEffect, useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { createClient } from '@/lib/supabase-browser';

function AuthForm() {
  const router=useRouter(), params=useSearchParams();
  const [mode,setMode]=useState(params.get('mode')==='signup'?'signup':'login');
  const [email,setEmail]=useState(''),[password,setPassword]=useState(''),[name,setName]=useState(''),[username,setUsername]=useState('');
  const [error,setError]=useState(''),[loading,setLoading]=useState(false);
  useEffect(()=>{ const supabase=createClient(); supabase.auth.getSession().then(({data})=>{if(data.session) router.replace('/dashboard')}); },[router]);
  async function submit(e:React.FormEvent){e.preventDefault();setLoading(true);setError('');const s=createClient();
    if(mode==='login'){const {error}=await s.auth.signInWithPassword({email,password});if(error)setError(error.message);else router.push('/dashboard');}
    else { if(username.length<3)return setError('Username must be at least 3 characters.'); const {data,error}=await s.auth.signUp({email,password,options:{data:{name,username:username.toLowerCase()}}}); if(error)setError(error.message); else if(data.session) router.push('/dashboard'); else setError('Check your email to confirm your account.'); }
    setLoading(false);
  }
  return <main className="min-h-screen grid-bg px-5 py-8"><div className="mx-auto max-w-md"><Link href="/" className="text-lg font-black">LINK<span className="text-white/35">PAGE</span></Link><div className="glass mt-10 rounded-3xl p-7 sm:p-9"><h1 className="text-3xl font-black">{mode==='login'?'Welcome back.':'Build your page.'}</h1><p className="mt-2 text-sm text-white/45">{mode==='login'?'Sign in to edit your LinkPage.':'Create your LinkPage in a minute.'}</p><form onSubmit={submit} className="mt-8 space-y-4">
    {mode==='signup'&&<><Field label="Name" value={name} setValue={setName} placeholder="Your name"/><Field label="Username" value={username} setValue={setUsername} placeholder="rajputads"/><p className="-mt-2 text-xs text-white/30">linkpage.app/{username||'username'}</p></>}
    <Field label="Email" value={email} setValue={setEmail} placeholder="you@example.com" type="email"/><Field label="Password" value={password} setValue={setPassword} placeholder="••••••••" type="password"/>
    {error&&<div className="rounded-xl border border-red-400/20 bg-red-400/5 px-3 py-2 text-sm text-red-300">{error}</div>}
    <button disabled={loading} className="w-full rounded-xl bg-white py-3.5 font-bold text-black disabled:opacity-50">{loading?'Please wait…':mode==='login'?'Sign in':'Create account'}</button>
  </form><button onClick={()=>{setMode(mode==='login'?'signup':'login');setError('')}} className="mt-6 w-full text-center text-sm text-white/45 hover:text-white">{mode==='login'?"Don't have an account? Sign up":"Already have an account? Sign in"}</button></div></div></main>
}
function Field({label,value,setValue,placeholder,type='text'}:{label:string,value:string,setValue:(v:string)=>void,placeholder:string,type?:string}){return <label className="block"><span className="mb-2 block text-xs font-semibold text-white/55">{label}</span><input required value={value} onChange={e=>setValue(e.target.value)} type={type} placeholder={placeholder} className="w-full rounded-xl border border-white/10 bg-white/[.04] px-4 py-3.5 outline-none placeholder:text-white/20 focus:border-white/30"/></label>}

export default function AuthPage(){ return <Suspense fallback={<main className="grid min-h-screen place-items-center bg-[#070707] text-white/40">Loading…</main>}><AuthForm/></Suspense>; }
