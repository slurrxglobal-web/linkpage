export type Profile = {
  id: string; user_id: string; username: string; name: string; bio: string;
  avatar_url: string | null; theme: string; background: string; created_at?: string; updated_at?: string;
};
export type LinkItem = {
  id: string; profile_id: string; title: string; url: string; type: string; icon: string; position: number; enabled: boolean;
};
